<?php 
require_once "usuario.php";
class Notas{
    
    public $id;
    public $idAlumno;
    public $nota;
    public $examen;
    public $fecha;
    public $materia;
    public $cuatrimestre;

    public function AgregarNota($request,$response,$args){
        $ArrayDeParametros = $request->getParsedBody();
        
        $idAlumno= $ArrayDeParametros['idAlumno'];
        $nota = $ArrayDeParametros['nota'];
        $examen = $ArrayDeParametros['examen'];
        $fecha= $ArrayDeParametros['fecha'];
        $materia= $ArrayDeParametros['materia'];
        $cuatrimestre= $ArrayDeParametros['cuatrimestre'];
        if(Usuario::TraerUnUsuarioId($idAlumno))
        {
        
            if($idAlumno!=null && $nota!=null && $examen!=null && $fecha!=null && $materia!=null && $cuatrimestre!=null)
            {
            $miNota = new Notas();
            $miNota->idAlumno=$idAlumno;
            $miNota->nota=$nota;
            $miNota->examen=$examen;
            $miNota->fecha=$fecha;
            $miNota->materia=$materia;
            $miNota->cuatrimestre=$cuatrimestre;
        
            $miNota->InsertarLaNotaParametros();
            $response->getBody()->write("se agrego la nota");
            }
            else{
            $response->getBody()->write("faltan ingresar datos");
            }
        }
        else{
            $response->getBody()->write("el alumno no existe");
        }
        return $response;
    }
    public function ListarPorCuatri($request,$response,$args){
        $cuatrimestre = $args["cuatrimestre"];
        $misNotas = Notas::TraerNotas($cuatrimestre);
        $response = $response->withJson($misNotas,200);
        return $response;
    }
    public function Modificar($request, $response, $args) {
       $ArrayDeParametros = $request->getParsedBody();
      
       $miNota = new Notas();
       $miNota->id=$ArrayDeParametros['id'];
       $miNota->idAlumno=$ArrayDeParametros['idAlumno'];
       $miNota->nota=$ArrayDeParametros['nota'];
       $miNota->examen=$ArrayDeParametros['examen'];
       $miNota->fecha=$ArrayDeParametros['fecha'];
       $miNota->materia=$ArrayDeParametros['materia'];
       $miNota->cuatrimestre=$ArrayDeParametros['cuatrimestre'];

          $resultado =$miNota->ModificarNotaParametros();
          $objDelaRespuesta= new stdclass();

          $objDelaRespuesta->resultado=$resultado;
            return $response->withJson($objDelaRespuesta, 200);		
   }

   public function Borrar($request, $response, $args) {
    $ArrayDeParametros = $request->getParsedBody();
    
    $id= $ArrayDeParametros['id'];
    
    $miNota= new Notas();
    $miNota->id=$id;
    $cantidadDeBorrados=$miNota->BorrarNota();

    $objDelaRespuesta= new stdclass();
    $objDelaRespuesta->cantidad=$cantidadDeBorrados;
    if($cantidadDeBorrados>0)
       {
            $objDelaRespuesta->resultado="borro!!!";
       }
       else
       {
           $objDelaRespuesta->resultado="no Borro nada!!!";
       }
   $newResponse = $response->withJson($objDelaRespuesta, 200);  
     return $newResponse;
}

   public function BorrarNota()
   {
           $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
          $consulta =$objetoAccesoDato->RetornarConsulta("
              delete 
              from Nota 				
              WHERE id=:id");	
              $consulta->bindValue(':id',$this->id, PDO::PARAM_INT);		
              $consulta->execute();
              return $consulta->rowCount();
   }
    public static function TraerNotas($cuatrimestre) 
	{
			$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
			$consulta =$objetoAccesoDato->RetornarConsulta("select * from Nota where cuatrimestre = '$cuatrimestre' ");
			$consulta->execute();
            $NotaBuscada= $consulta->fetchAll(PDO::FETCH_CLASS,'Notas');
			return $NotaBuscada;			

			
    }
    public function ModificarNotaParametros()
    {
           $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
           $consulta =$objetoAccesoDato->RetornarConsulta("
               update Nota 
               set idAlumno=:idAlumno,
               nota=:nota,
               examen=:examen,
               fecha=:fecha,
               materia=:materia,
               cuatrimestre=:cuatrimestre

               WHERE id=:id");
           $consulta->bindValue(':id',$this->id, PDO::PARAM_INT);
           $consulta->bindValue(':idAlumno',$this->idAlumno, PDO::PARAM_INT);
           $consulta->bindValue(':nota',$this->nota, PDO::PARAM_INT);
           $consulta->bindValue(':examen',$this->examen, PDO::PARAM_STR);
           $consulta->bindValue(':fecha', $this->fecha, PDO::PARAM_STR);
           $consulta->bindValue(':materia', $this->materia, PDO::PARAM_STR);
           $consulta->bindValue(':cuatrimestre',$this->cuatrimestre, PDO::PARAM_STR);
           return $consulta->execute();
    }
    public function InsertarLaNotaParametros()
    {
               $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
               $consulta =$objetoAccesoDato->RetornarConsulta("INSERT into Nota (idAlumno,nota,examen,fecha,materia,cuatrimestre)values(:idAlumno,:nota,:examen,:fecha,:materia,:cuatrimestre)");
               $consulta->bindValue(':idAlumno',$this->idAlumno, PDO::PARAM_INT);
               $consulta->bindValue(':nota', $this->nota, PDO::PARAM_INT);
               $consulta->bindValue(':examen', $this->examen, PDO::PARAM_STR);
               $consulta->bindValue(':fecha', $this->fecha, PDO::PARAM_STR);
               $consulta->bindValue(':materia', $this->materia, PDO::PARAM_STR);
               $consulta->bindValue(':cuatrimestre', $this->cuatrimestre, PDO::PARAM_STR);
               $consulta->execute();		
               return $objetoAccesoDato->RetornarUltimoIdInsertado();
    }


}

?>