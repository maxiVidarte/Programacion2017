<?php
class Usuario
{
	public $id;
 	public $nombre;
  	public $apellido;
	public $email;
	public $foto;
	public $legajo;
	public $clave;
	public $perfil;
	  
 	public function TraerUno($request, $response, $args) {
		$ArrayDeParametros = $request->getParsedBody();
		$email=$ArrayDeParametros['email'];
		$clave= $ArrayDeParametros['clave'];
		$datos=Usuario::TraerUnUsuario($email,$clave);
		$elToken = Usuario::CreaToken($request,$response);
        $newResponse = $response->withJson($datos, 200);  
	    if($datos!=null){
			return "{'valido':'true','usuario':$newResponse,'token':$elToken}";
		}
    	else{
			return "{'valido':'false'}";
        }
    }
    public function AgregarUsuario($request,$response,$args){
        $ArrayDeParametros = $request->getParsedBody();
        //var_dump($ArrayDeParametros);
        $nombre= $ArrayDeParametros['nombre'];
        $apellido= $ArrayDeParametros['apellido'];
        $email= $ArrayDeParametros['email'];
        $legajo = $ArrayDeParametros['legajo'];
        $clave = $ArrayDeParametros['clave'];
        $perfil  =$ArrayDeParametros['perfil'];
        $foto  = "/fotos/".$email.".jpg";

        if($nombre!=null && $apellido!=null && $email!=null && $legajo!=null && $clave!=null && $perfil!=null && $foto!=null){

        $miUsuario = new Usuario();
        $miUsuario->nombre=$nombre;
        $miUsuario->apellido=$apellido;
        $miUsuario->email=$email;
        $miUsuario->legajo=$legajo;
        $miUsuario->clave=$clave;
        $miUsuario->perfil=$perfil;
        $miUsuario->foto = $foto;
        
        
        $miUsuario->InsertarElUsuarioParametros();
    
        $archivos = $request->getUploadedFiles();
        $destino="./fotos/";
            
        $nombreAnterior=$archivos['foto']->getClientFilename();
        $extension= explode(".", $nombreAnterior)  ;
        
        $extension=array_reverse($extension);
        $foto = $destino.$email;

        $archivos['foto']->moveTo($destino.$email.".jpg");
        $response->getBody()->write("el usuario se agrego correctamente");
    }
    else{
        $response->getBody()->write("no se pudo agregar usuario");
    }
        return $response;

        
    }
     public function TraerTodos($request, $response, $args) {
      	$todosLosUsuarios=Usuario::TraerTodoLosUsuarios();
     	$newResponse = $response->withJson($todosLosUsuarios, 200);  
    	return $newResponse;
	}
	public function CreaToken($request, $response) {
		$ArrayDeParametros = $request->getParsedBody();
		$datos = array('email' => $ArrayDeParametros['email'],'clave' => $ArrayDeParametros['clave']);
		$token= AutentificadorJWT::CrearToken($datos);  
		return $token;
	}
      public function CargarUno($request, $response, $args) {
     	$response->getBody()->write("<h1>Cargar uno nuevo</h1>");
      	return $response;
    }
	
	 public function InsertarElUsuarioParametros()
	 {
				$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
				$consulta =$objetoAccesoDato->RetornarConsulta("INSERT into usuario (nombre,apellido,email,foto,legajo,clave,perfil)values(:nombre,:apellido,:email,:foto,:legajo,:clave,:perfil)");
				$consulta->bindValue(':nombre',$this->nombre, PDO::PARAM_STR);
				$consulta->bindValue(':apellido', $this->apellido, PDO::PARAM_STR);
				$consulta->bindValue(':email', $this->email, PDO::PARAM_STR);
				$consulta->bindValue(':foto', $this->foto, PDO::PARAM_STR);
				$consulta->bindValue(':legajo', $this->legajo, PDO::PARAM_INT);
				$consulta->bindValue(':clave', $this->clave, PDO::PARAM_STR);
				$consulta->bindValue(':perfil', $this->perfil, PDO::PARAM_STR);
				$consulta->execute();		
				return $objetoAccesoDato->RetornarUltimoIdInsertado();
	 }
	  	public static function TraerTodoLosUsuarios()
	{
			$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
			$consulta =$objetoAccesoDato->RetornarConsulta("select * from Usuario");
			$consulta->execute();			
			return $consulta->fetchAll(PDO::FETCH_CLASS, "Usuario");		
	}

	public static function TraerUnUsuario($email,$clave) 
	{
			$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
			$consulta =$objetoAccesoDato->RetornarConsulta("select nombre,apellido,email,foto,legajo,perfil from Usuario where email = '$email' AND clave = '$clave' ");
			$consulta->execute();
            $UsuarioBuscado= $consulta->fetchObject('Usuario');
			return $UsuarioBuscado;			

			
    }
    public static function TraerUnUsuarioId($id) 
	{
			$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
			$consulta =$objetoAccesoDato->RetornarConsulta("select nombre,apellido,email,foto,legajo,perfil from Usuario where id= '$id' ");
			$consulta->execute();
            $UsuarioBuscado= $consulta->fetchObject('Usuario');
			return $UsuarioBuscado;			

			
	}

	

	public function mostrarDatos()
	{
	  	return "Metodo mostar:".$this->titulo."  ".$this->cantante."  ".$this->año;
	}

}