<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require_once './clases/AutentificadorJWT.php';
require_once './composer/vendor/autoload.php';
require_once './clases/AccesoDatos.php';
require_once './clases/usuario.php';
require_once './clases/notas.php';


$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;


$app = new \Slim\App(["settings" => $config]);

$app->group('/Notas',function(){

    $this->post('/agregar', \Notas::class. ':AgregarNota');

    $this->get('/cuatrimestre/{cuatrimestre}',\Notas::class. ':ListarPorCuatri');

    $this->post('/modificar',\Notas::class. ':Modificar');

    $this->delete('/borrar', \Notas::class. ':Borrar');
    
});


$app->group('/Usuarios', function () {
   
    
    $this->get('/', \Usuario::class. ':TraerTodos');

    $this->post('/login/', \Usuario::class . ':traerUno');
   
    $this->post('/', \Usuario::class. ':AgregarUsuario');    
           
});

 $app->run();